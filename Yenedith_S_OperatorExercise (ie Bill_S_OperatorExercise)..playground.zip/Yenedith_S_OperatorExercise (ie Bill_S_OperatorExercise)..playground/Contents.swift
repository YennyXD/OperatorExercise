import UIKit
//imput variables
var number1 = 678
var number2 = 189
 
// Operation
var add = number1 + number2
var sub = number1 - number2
var mult = number1 * number2
var div = number1 / number2

//The print
print (add)
print(sub)
print(mult)
print(div)
