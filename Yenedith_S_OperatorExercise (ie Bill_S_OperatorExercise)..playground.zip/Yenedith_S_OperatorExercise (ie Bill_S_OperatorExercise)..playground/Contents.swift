import UIKit

// defining my variables and my constants
// total amount of time is 5 minutes, which will be converted to seconds
let TotalTime = 300
// start the timer at 0  and count to 300
for Timer in 0...TotalTime
{
    //prints each second of the time
   print("\(Timer) seconds")
    // Brings up message "!!TIMES UP!!" at 300 seconds
    if  Timer == TotalTime{
      print("!!TIMES UP!!")
    }
}
